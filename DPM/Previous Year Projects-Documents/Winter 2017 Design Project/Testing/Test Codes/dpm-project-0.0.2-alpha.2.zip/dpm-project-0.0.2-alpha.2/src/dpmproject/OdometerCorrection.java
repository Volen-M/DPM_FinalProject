package dpmproject;
import interfacePackages.OdometerCorrectionInterface;
import interfacePackages.OdometerInterface;
import interfacePackages.SensorInterface;

/**
 * 
 */

/**
 * @author Ali
 *
 */
public class OdometerCorrection extends Thread implements OdometerCorrectionInterface {
	
	public OdometerCorrection(OdometerInterface odo, SensorInterface leftColor, SensorInterface rightColor) {
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		super.run();
	}

	@Override
	public void correctX() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void correctY() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void pause() {
		// TODO Auto-generated method stub
		
	}

}
