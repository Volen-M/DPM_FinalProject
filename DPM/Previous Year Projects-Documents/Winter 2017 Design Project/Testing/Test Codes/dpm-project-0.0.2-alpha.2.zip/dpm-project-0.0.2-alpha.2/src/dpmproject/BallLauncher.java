package dpmproject;
/**
 * 
 */
import interfacePackages.BallLauncherInterface;
/**
 * @author Ali
 *
 */
public class BallLauncher extends Thread implements BallLauncherInterface {

	@Override
	public boolean reload() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void fire() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean reset() {
		// TODO Auto-generated method stub
		return false;
	}

}
