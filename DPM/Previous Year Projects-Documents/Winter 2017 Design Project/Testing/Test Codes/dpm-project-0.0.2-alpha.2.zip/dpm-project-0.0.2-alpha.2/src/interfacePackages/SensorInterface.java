/**
 * 
 */
package interfacePackages;

/**
 * @author Ali
 *
 */
public interface SensorInterface {
	
	public double getFilteredData();
	
	public double getRawData();
	
	public double read();

}
