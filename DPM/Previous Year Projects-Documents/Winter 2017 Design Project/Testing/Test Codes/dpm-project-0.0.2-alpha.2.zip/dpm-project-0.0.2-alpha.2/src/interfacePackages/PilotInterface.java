package interfacePackages;

public interface PilotInterface {

	public void travel();
}
